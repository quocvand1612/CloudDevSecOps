import json
import logging
import os
import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

ec2 = boto3.client('ec2')

def lambda_handler(event, context):
    logger.info("Security Finding Received: %s", json.dumps(event))
    
    detail = event.get('detail', {})
    finding_type = detail.get('type', 'Custom-DevSecOps-Alert')
    severity = detail.get('severity', 0)
    resource = detail.get('resource', {})
    
    logger.warning(f"ALERT: High-Severity Finding [{finding_type}] detected! Severity={severity}")
    
    instance_id = resource.get('instanceDetails', {}).get('instanceId')
    if instance_id:
        logger.info(f"Applying automated quarantine tag to instance: {instance_id}")
        ec2.create_tags(
            Resources=[instance_id],
            Tags=[{'Key': 'SecurityStatus', 'Value': 'Quarantined-By-SOAR-Lambda'}]
        )
    
    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'Security incident evaluated and quarantine applied.',
            'finding_type': finding_type
        })
    }
